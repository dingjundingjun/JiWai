package com.umeng.commm.ui.fragments;

import android.view.View;

import com.umeng.comm.core.beans.FeedItem;
import com.umeng.comm.core.utils.Log;
import com.umeng.comm.ui.imagepicker.util.BroadcastUtils;
import com.umeng.commm.ui.presenter.impl.HottestFeedPresenter;

import java.util.List;

/**
 * Created by umeng on 12/1/15.
 */
public class HotFeedsFragment extends FeedListFragment<HottestFeedPresenter> {

    HottestFeedPresenter mHottestFeedPresenter;

    @Override
    protected void initWidgets() {
        super.initWidgets();
        mPostBtn.setVisibility(View.GONE);
    }

    @Override
    protected void initEventHandlers() {
        super.initEventHandlers();
    }

    @Override
    protected HottestFeedPresenter createPresenters() {
        mHottestFeedPresenter = new HottestFeedPresenter(this);
        return mHottestFeedPresenter;
    }
    @Override
    protected void registerBroadcast() {
        // 注册广播接收器
        BroadcastUtils.registerUserBroadcast(getActivity(), mReceiver);
       BroadcastUtils.registerFeedBroadcast(getActivity(), mReceiver);
        BroadcastUtils.registerFeedUpdateBroadcast(getActivity(), mReceiver);
    }
    @Override
    public List<FeedItem> getBindDataSource() {
        return super.getBindDataSource();
    }

    @Override
    public void notifyDataSetChanged() {
        super.notifyDataSetChanged();
    }
    @Override
    protected void postFeedComplete(FeedItem feedItem) {

    }
    @Override
    protected void deleteFeedComplete(FeedItem feedItem) {
        mFeedLvAdapter.getDataSource().remove(feedItem);
        mFeedLvAdapter.notifyDataSetChanged();
        updateForwardCount(feedItem, -1);
        Log.d(getTag(), "### 删除feed");
    }
    @Override
    public void clearListView() {
        super.clearListView();
    }

}
