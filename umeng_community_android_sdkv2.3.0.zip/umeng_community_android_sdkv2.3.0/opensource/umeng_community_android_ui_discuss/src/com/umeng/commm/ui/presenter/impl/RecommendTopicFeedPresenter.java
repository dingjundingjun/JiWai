package com.umeng.commm.ui.presenter.impl;

import com.umeng.commm.ui.mvpview.MvpFeedView;

/**
 * Created by wangfei on 15/12/2.
 */
public class RecommendTopicFeedPresenter extends TopicFeedPresenter{
    public RecommendTopicFeedPresenter(MvpFeedView view) {
        super(view);
    }
    @Override
    public void loadDataFromServer() {
        mCommunitySDK.fetchTopicRecommendFeed(mId, mRefreshListener);
    }

    @Override
    public void loadDataFromDB() {

    }
}
