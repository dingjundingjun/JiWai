package com.umeng.commm.ui.presenter.impl;

import android.text.TextUtils;
import com.umeng.comm.core.beans.FeedItem;
import com.umeng.comm.core.db.ctrl.impl.DatabaseAPI;
import com.umeng.comm.core.listeners.Listeners;
import com.umeng.comm.core.nets.responses.FeedsResponse;
import com.umeng.comm.core.nets.uitls.NetworkUtils;
import com.umeng.comm.core.utils.Log;
import com.umeng.commm.ui.mvpview.MvpFeedView;


import java.util.List;

/**
 * Created by umeng on 12/1/15.
 */
public class HottestFeedPresenter extends FeedListPresenter {

    public volatile static int HOT_DAYS = 30;


    public HottestFeedPresenter(MvpFeedView view) {
        super(view);
    }

    public HottestFeedPresenter(MvpFeedView view, boolean isRegisterLoginBroadcast) {
        super(view, isRegisterLoginBroadcast);
    }

    public void setHOT_DAYS(int HOT_DAYS) {
        if (this.HOT_DAYS !=HOT_DAYS){
            setIsNeedRemoveOldFeeds();
        }
        this.HOT_DAYS = HOT_DAYS;
    }

    @Override
    protected void saveDataToDB(List<FeedItem> newFeedItems) {
        super.saveDataToDB(newFeedItems);
    }

    @Override
    public void loadDataFromDB() {
        DatabaseAPI.getInstance().getFeedDBAPI().loadHottestFeeds(HOT_DAYS, new Listeners.SimpleFetchListener<List<FeedItem>>() {
            @Override
            public void onComplete(List<FeedItem> response) {
                com.umeng.comm.core.utils.Log.d("db","loading"+response.size());
                mDbFetchListener.onComplete(response);
            }
        });
    }


    /**
     *
     * @param days
     */
    public void loadDataFromServer(int days){
        if(days == 1 || days==3 || days == 7 || days ==30){
            setHOT_DAYS(days);
            loadDataFromServer();
        }
    }


    @Override
    public void loadDataFromServer() {
        mCommunitySDK.fetchHotestFeeds(new Listeners.FetchListener<FeedsResponse>() {
            @Override
            public void onStart() {
                mFeedView.onRefreshStart();
                mFeedView.clearListView();
            }

            @Override
            public void onComplete(FeedsResponse response) {
                // 根据response进行Toast
                if (NetworkUtils.handleResponseAll(response)) {
                    mFeedView.onRefreshEnd();
                    return;
                }

                final List<FeedItem> newFeedItems = response.result;

                for(FeedItem feedItem : newFeedItems){
                    feedItem.isHot=true;
                }

                // 对于下拉刷新，仅在下一个地址为空（首次刷新）时设置下一页地址
                if (TextUtils.isEmpty(mNextPageUrl) && isNeedRemoveOldFeeds.get()) {
                    mNextPageUrl = response.nextPageUrl;
                }
                beforeDeliveryFeeds(response);
                // 更新数据
                int news = addFeedItemsToHeader(newFeedItems);
                // 保存加载的数据。如果该数据存在于DB中，则替换成最新的，否则Insert一条新纪录
                saveDataToDB(newFeedItems);
                mFeedView.onRefreshEnd();

            }
        },HOT_DAYS,0);
    }
}
