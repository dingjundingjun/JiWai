package com.umeng.commm.ui.presenter.impl;

import android.text.TextUtils;

import com.umeng.comm.core.beans.Topic;
import com.umeng.comm.core.listeners.Listeners;
import com.umeng.comm.core.nets.responses.TopicResponse;
import com.umeng.comm.core.nets.uitls.NetworkUtils;
import com.umeng.comm.core.utils.Log;
import com.umeng.commm.ui.mvpview.MvpRecyclerView;
import com.umeng.commm.ui.presenter.BaseFragmentPresenter;

import java.util.List;

/**
 * Created by umeng on 12/10/15.
 */
public class TopicSearchPresenter extends BaseFragmentPresenter<List<Topic>> {
    private String mNextPageUrl;
    private MvpRecyclerView mvpRecommendTopicView;
    private List<Topic> mTopicList;


    public TopicSearchPresenter(MvpRecyclerView mvpRecommendTopicView,List<Topic> topicList) {
        this.mvpRecommendTopicView = mvpRecommendTopicView;
        this.mTopicList = topicList;
    }

    @Override
    public void loadDataFromServer() {

    }

    public void executeSearch(String searchKeyWord){
        mCommunitySDK.searchTopic(searchKeyWord, new Listeners.SimpleFetchListener<TopicResponse>() {
            @Override
            public void onComplete(TopicResponse response) {
                mvpRecommendTopicView.onRefreshEnd();
                if(NetworkUtils.handleResponseAll(response)){
                    mTopicList.clear();
                    mvpRecommendTopicView.onDataSetChanged();
                    return;
                }
                mNextPageUrl = response.nextPageUrl;
                mTopicList.clear();
                mTopicList.addAll(response.result);
                mvpRecommendTopicView.onDataSetChanged();
            }

            @Override
            public void onStart() {
                super.onStart();
                mvpRecommendTopicView.onRefreshStart();
            }
        });
    }

    public void fetchNextPageData(){

        if(!TextUtils.isEmpty(mNextPageUrl)){

            mCommunitySDK.fetchNextPageData(mNextPageUrl, TopicResponse.class, new Listeners.FetchListener<TopicResponse>() {
            @Override
            public void onStart() {
//                mvpRecommendTopicView.showProgressFooter();
//                mvpRecommendTopicView.onRefreshStart();
            }

            @Override
            public void onComplete(TopicResponse response) {
//                mvpRecommendTopicView.hideProgressFooter();
//                mvpRecommendTopicView.onRefreshEnd();
                if(NetworkUtils.handleResponseAll(response)){

                    return;
                }
                if(response!=null){
                    mNextPageUrl = response.nextPageUrl;

                    mTopicList.addAll(mTopicList.size()-1,response.result);
                    mvpRecommendTopicView.onDataSetChanged();
                }
            }
        });
        }
    }
}
