package com.umeng.commm.ui.presenter.impl;

import com.umeng.commm.ui.mvpview.MvpFeedView;

/**
 * Created by wangfei on 15/12/8.
 */
public class SearchTopicPresenter extends FeedListPresenter {


    public SearchTopicPresenter(MvpFeedView view) {
        super(view);
    }
}
