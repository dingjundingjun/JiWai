package com.umeng.commm.ui.presenter.impl;

import com.umeng.commm.ui.activities.TopicDetailActivity;
import com.umeng.commm.ui.mvpview.MvpFeedView;

/**
 * Created by wangfei on 15/12/2.
 */
public class HotTopicFeedPresenter extends TopicFeedPresenter{
    private int hottype = 1;

    public HotTopicFeedPresenter(MvpFeedView view) {
        super(view);
    }

    @Override
    public void loadDataFromServer() {
        int days = 1;
        if (hottype!=TopicDetailActivity.HOTTYPE){
            mFeedView.getBindDataSource().clear();
            mFeedView.notifyDataSetChanged();
            hottype = TopicDetailActivity.HOTTYPE;
        }
        switch (TopicDetailActivity.HOTTYPE){
            case 0:
                days =1;
                break;
            case 1:
                days =3;
                break;
            case 2:
                days =7;
                break;
            case 3:
                days =30;
                break;
        }
        mCommunitySDK.fetchTopicHotestFeeds(mId, mRefreshListener, days, 0);
    }

    @Override
    public void loadDataFromDB() {

    }
}
