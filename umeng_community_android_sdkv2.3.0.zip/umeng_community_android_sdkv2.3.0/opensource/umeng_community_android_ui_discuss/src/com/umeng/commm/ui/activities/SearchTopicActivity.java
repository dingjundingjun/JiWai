package com.umeng.commm.ui.activities;

import android.os.Bundle;

import com.umeng.comm.core.utils.ResFinder;
import com.umeng.commm.ui.fragments.SearchTopicFragment;

/**
 * Created by wangfei on 15/12/8.
 */
public class SearchTopicActivity extends BaseFragmentActivity{
    private SearchTopicFragment mSearchFragment;

    @Override
    protected void onCreate(Bundle bundle) {
        super.onCreate(bundle);
        setContentView(ResFinder.getLayout("umeng_comm_search_activity"));
        mSearchFragment = new SearchTopicFragment();
        int container = ResFinder.getId("umeng_comm_main_container");
        setFragmentContainerId(container);
        showFragmentInContainer(container, mSearchFragment);
    }
}
