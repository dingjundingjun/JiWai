package com.umeng.commm.ui.fragments;

import android.view.View;

import com.umeng.comm.core.beans.FeedItem;
import com.umeng.comm.core.beans.Topic;
import com.umeng.comm.core.utils.Log;
import com.umeng.comm.core.utils.ResFinder;
import com.umeng.comm.ui.imagepicker.util.BroadcastUtils;
import com.umeng.commm.ui.presenter.impl.HotTopicFeedPresenter;
import com.umeng.commm.ui.utils.Filter;

import java.util.Iterator;
import java.util.List;

/**
 * Created by wangfei on 15/12/2.
 */
public class HotTopicFeedFragment extends TopicFeedFragment{
    public static HotTopicFeedFragment newTopicFeedFrmg(final Topic topic) {
        HotTopicFeedFragment topicFeedFragment = new HotTopicFeedFragment();
        topicFeedFragment.mTopic = topic;
        topicFeedFragment.mFeedFilter = new Filter<FeedItem>() {

            @Override
            public List<FeedItem> doFilte(List<FeedItem> newItems) {
                if (newItems == null || newItems.size() == 0) {
                    return newItems;
                }
                Iterator<FeedItem> iterator = newItems.iterator();
                while (iterator.hasNext()) {
                    List<Topic> topics = iterator.next().topics;
                    if (!topics.contains(topic)) {
                        iterator.remove();
                    }
                }
                return newItems;
            }
        };
        return topicFeedFragment;
    }

    @Override
    protected HotTopicFeedPresenter createPresenters() {
        HotTopicFeedPresenter presenter = new HotTopicFeedPresenter(this);
        presenter.setId(mTopic.id);
        return presenter;
    }

    @Override
    protected void initWidgets() {
        super.initWidgets();
//        BroadcastUtils.unRegisterBroadcast(getActivity(), mReceiver);
        findViewById(ResFinder.getId("umeng_comm_new_post_btn")).setVisibility(View.GONE);
    }

    public void ChangeFragment(int hottype,boolean isneedsavenextpage){

        if (mPresenter!=null) {
            if (isneedsavenextpage){
                mPresenter.setIsNeedRemoveOldFeeds();
            }
            mPresenter.loadDataFromServer();
        }
    }
    @Override
    protected void postFeedComplete(FeedItem feedItem) {

    }
    @Override
    protected void deleteFeedComplete(FeedItem feedItem) {
        mFeedLvAdapter.getDataSource().remove(feedItem);
        mFeedLvAdapter.notifyDataSetChanged();
        updateForwardCount(feedItem, -1);
        Log.d(getTag(), "### 删除feed");
    }
}
